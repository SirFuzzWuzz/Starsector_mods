package data.hullmods;

//import com.fs.starfarer.api.Global;
//import java.util.HashMap;
//import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;

import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipEngineControllerAPI.ShipEngineAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.List;
import org.lazywizard.lazylib.VectorUtils;

//import java.awt.Color;


public class enginedirt extends BaseHullMod {
    
        //private static final String big_id = "time_id";
        
        //private final String bigId = "engineDirt";
        private final float zeroFluxBoostMult = 1.5f;
        private final float engineDamageTakenMult = 1.25f;
    
        private IntervalUtil interval; // = new IntervalUtil(0.5f,1f);
        //private float intensity = 0;
        
        @Override
        public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
            
            stats.getEngineDamageTakenMult().modifyMult(id, engineDamageTakenMult);
            
            
            if (hullSize == HullSize.FRIGATE) {
                interval = new IntervalUtil(0.5f,1f);
                stats.getZeroFluxSpeedBoost().modifyMult(id, zeroFluxBoostMult);
            }
            else if (hullSize == HullSize.DESTROYER){
                interval = new IntervalUtil(0.4f,0.8f);
                stats.getZeroFluxSpeedBoost().modifyMult(id, zeroFluxBoostMult - 0.1f);
            }
            else if (hullSize == HullSize.CRUISER) {
                interval = new IntervalUtil(0.3f,0.6f);
                stats.getZeroFluxSpeedBoost().modifyMult(id, zeroFluxBoostMult - 0.2f);
            }
            else if (hullSize == HullSize.CAPITAL_SHIP) {
                interval = new IntervalUtil(0.2f,0.4f);
                stats.getZeroFluxSpeedBoost().modifyMult(id, zeroFluxBoostMult - 0.3f);
            } else {
                interval = new IntervalUtil(0.5f,1f);
                stats.getZeroFluxSpeedBoost().modifyMult(id, zeroFluxBoostMult);
            }

            
            /*switch(hullSize) {
            case FRIGATE:
            interval = new IntervalUtil(0.5f,1f);
            break; // fallthrough is stoopid
            case DESTROYER:
            interval = new IntervalUtil(0.4f,0.9f);
            break;
            case CRUISER:
            interval = new IntervalUtil(0.3f,0.8f);
            break;
            case CAPITAL_SHIP:
            interval = new IntervalUtil(0.2f,0.7f);
            break;
            default:
            interval = new IntervalUtil(0.5f,1f);
            }*/
        }
        
        /*public void applyEffectsAfterShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        
        }*/
        
        @Override
	public void advanceInCombat(ShipAPI ship, float amount) {            
            
            CombatEngineAPI engine = Global.getCombatEngine();
            interval.advance(amount);
            
            if (interval.intervalElapsed() && ship.getEngineController().isAccelerating()) {
                
                List<ShipEngineAPI> shipEngines = ship.getEngineController().getShipEngines();
                int rng = (int) Math.round((shipEngines.size()-1) * Math.random());
                ShipEngineAPI shipEng = (ShipEngineAPI) shipEngines.get(rng);
                
                float angle = VectorUtils.getAngle(ship.getLocation(), shipEng.getLocation());
                engine.spawnProjectile(ship, null, "flarelauncher1", shipEng.getLocation(), angle, ship.getVelocity());
            }

	} //advanceInCombat

        @Override
         public boolean isApplicableToShip(ShipAPI ship) {
             return !ship.getEngineController().getShipEngines().isEmpty() && !ship.getHullSpec().isPhase();
         }
        
	@Override
	public String getUnapplicableReason(ShipAPI ship) {
                /*if (ship.getVariant().hasHullMod(HullMods.PHASE_ANCHOR)) {
			return "Incompatible with Phase Anchor";
		}*/
		if (ship.getEngineController().getShipEngines().isEmpty()) return "Ship has no engines";

                if (ship.getHullSpec().isPhase()) return "Cannot be installed on phase ships";
                
		return super.getUnapplicableReason(ship);
	}

}
