package data.hullmods;

import com.fs.starfarer.api.Global;


import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EmpArcEntityAPI;
import com.fs.starfarer.api.combat.FighterLaunchBayAPI;
import com.fs.starfarer.api.combat.FighterWingAPI;

import com.fs.starfarer.api.combat.GuidedMissileAI;
import com.fs.starfarer.api.combat.MissileAPI;

import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;
import com.fs.starfarer.api.impl.combat.DroneStrikeStats;
import com.fs.starfarer.api.impl.combat.DroneStrikeStatsAIInfoProvider;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;

import java.util.List;
import org.lwjgl.util.vector.Vector2f;
//ty arthr for icon

public class patherpilots extends BaseHullMod implements DroneStrikeStatsAIInfoProvider {
    
        //private static final String big_id = "pp_id";
        
    
        @Override
        public boolean isApplicableToShip(ShipAPI ship) {
            
            if (ship.getVariant().hasHullMod(HullMods.RECOVERY_SHUTTLES)) return false;
            int bays = (int) ship.getMutableStats().getNumFighterBays().getModifiedValue();
            return bays > 0; // not null = has phase = true = big brain
        }
        
        @Override
	public String getUnapplicableReason(ShipAPI ship) {
                /*if (ship.getVariant().hasHullMod(HullMods.PHASE_ANCHOR)) {
			return "Incompatible with Phase Anchor";
		}*/
		if (!ship.hasLaunchBays()) {
			return "Can only be installed on ships with fighter bays";
		}
                if (ship.getVariant().hasHullMod(HullMods.RECOVERY_SHUTTLES)) {
                    return "Incompatible with Recovery Shuttles, these boys aren't going home";
                }
                

                /*for (FighterLaunchBayAPI bay : ship.getLaunchBaysCopy()) {
                    if (bay.getWing().getWingId().contains("vic_")) {
                        return "Incompatible with VIC fighters";
                    }
                }*/
                
		return super.getUnapplicableReason(ship);
	}
        
	
	public void advanceInCombat(ShipAPI ship, float amount) {
            CombatEngineAPI engine = Global.getCombatEngine();
                        
            if (!ship.isAlive()) return;
            
            
            for (FighterLaunchBayAPI bay : ship.getLaunchBaysCopy()) {
                if (bay.getWing() == null) continue;
                /*if (bay.getWing().getWingId().contains("vic_")) {
                    //engine.addFloatingText(ship.getLocation(), "NO CRASHING!", 8f, Color.red, ship, 3, 1);
                    continue;
                }*/
                for (ShipAPI fighter: bay.getWing().getWingMembers()) {
                    if (fighter.isDrone()) return;
                    if (fighter.getHitpoints() <= fighter.getMaxHitpoints()*0.5) {
                        fighter.setShipAI(null);
                        convertDrones(fighter, fighter.getShipTarget());
                    
                    }
                    
                }
            }
            

	}

        
        protected WeaponAPI weapon;
	protected boolean fired = false;
        
        protected ShipAPI forceNextTarget;


        public void convertDrones(ShipAPI ship, final ShipAPI target) {
		CombatEngineAPI engine = Global.getCombatEngine();
		fired = true;
		forceNextTarget = null;
                
                ShipAPI drone = ship;
                //drone.setShipAI(null);

                MissileAPI missile = (MissileAPI) engine.spawnProjectile(
                                ship, weapon, getWeaponId(),
                                new Vector2f(drone.getLocation()), drone.getFacing(), new Vector2f(drone.getVelocity()));
                if (target != null && missile.getAI() instanceof GuidedMissileAI) {
                        GuidedMissileAI ai = (GuidedMissileAI) missile.getAI();
                        ai.setTarget(target);
                }

                //missile.setHitpoints(missile.getHitpoints() * drone.getHullLevel());
                missile.setEmpResistance(10000);

                float base = missile.getMaxRange();
                float max = getMaxRange(ship);
                missile.setMaxRange(max);
                missile.setMaxFlightTime(missile.getMaxFlightTime() * max/base);

                ship.setHitpoints(ship.getMaxHitpoints());
                //missile.setHitpoints(1.5f*ship.getMaxHitpoints());
                missile.setDamageAmount(2f*ship.getMaxHitpoints());

                //Double check this with modded fighters
                drone.getWing().removeMember(drone);
                //drone.setWing(null);
                
                drone.setExplosionFlashColorOverride(new Color(255, 150, 50, 255));
                engine.addLayeredRenderingPlugin(new DroneStrikeStats.DroneMissileScript(drone, missile));

                //float thickness = 16f;
                float thickness = 20f;
                float coreWidthMult = 0.67f;
                EmpArcEntityAPI arc = engine.spawnEmpArcVisual(ship.getLocation(), ship,
                                missile.getLocation(), missile, thickness, new Color(255,100,100,255), Color.white);
                arc.setCoreWidthOverride(thickness * coreWidthMult);
                arc.setSingleFlickerMode();

                //engine.addFloatingText(vctrf, string, max, Color.yellow, arc, max, max);
                engine.addFloatingText(ship.getLocation(), "FOR LUDD!", 10f, Color.red, ship, 3, 1);
	}
        
        protected String getWeaponId() {
		return "terminator_missile";
	}
        
        
        public List<ShipAPI> getDrones(ShipAPI ship) {
		List<ShipAPI> result = new ArrayList<ShipAPI>();
		for (FighterLaunchBayAPI bay : ship.getLaunchBaysCopy()) {
			if (bay.getWing() == null) continue;
			for (ShipAPI drone : bay.getWing().getWingMembers()) {
				result.add(drone);
			}
		}
		return result;
	}
	public float getMaxRange(ShipAPI ship) {
		if (weapon == null) {
			weapon = Global.getCombatEngine().createFakeWeapon(ship, getWeaponId());
		}
		//return weapon.getRange();
		return ship.getMutableStats().getSystemRangeBonus().computeEffective(weapon.getRange());
	}
        public boolean dronesUsefulAsPD() {
		return true;
	}
	public boolean droneStrikeUsefulVsFighters() {
		return false;
	}
	public int getMaxDrones() {
		return 99;
	}
	public float getMissileSpeed() {
		return weapon.getProjectileSpeed();
	}
	public void setForceNextTarget(ShipAPI forceNextTarget) {
		this.forceNextTarget = forceNextTarget;
	}
	public ShipAPI getForceNextTarget() {
		return forceNextTarget;
	}

}
