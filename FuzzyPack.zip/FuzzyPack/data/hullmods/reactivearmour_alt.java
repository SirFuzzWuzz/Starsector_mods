package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ArmorGridAPI;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.CombatEngineAPI;

import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.listeners.AdvanceableListener;
import java.util.ArrayList;
/*import com.fs.starfarer.api.impl.campaign.ids.HullMods;
import java.util.HashMap;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;*/ 
//ty banano for some lazylib vector help, lucas for advanceable listener setup

import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;


public class reactivearmour_alt extends BaseHullMod {

    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id)
    {
        ship.addListener(new listener(ship));
    }


    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        return !ship.getVariant().hasHullMod("reactivearmour_kinetic"); // not null = has phase = true = big brain
    }


    @Override
    public String getUnapplicableReason(ShipAPI ship) {
        if (ship.getVariant().hasHullMod("reactivearmour_kinetic")) {
            return "Can only install one type of Reactive Armour";
        }
        return null;
    }

    class listener implements AdvanceableListener
    {

        CombatEngineAPI engine = Global.getCombatEngine();
        //Boolean activated = false;
        ShipAPI ship;
        
        ArrayList<Vector2f> firedCells = new ArrayList<Vector2f>();


        public listener(ShipAPI ship)
        {
            this.ship = ship;
        }

        @Override
        public void advance(float amount)
        {
            if (ship.isHulk()) return;

            ArmorGridAPI grid = ship.getArmorGrid();

            int gridWidth = grid.getGrid().length;
            int gridHeight = grid.getGrid()[0].length;
            //float maxArmorInCell = grid.getMaxArmorInCell();
            

            for (int x = 0; x < gridWidth; x++) {
                for (int y = 0; y < gridHeight; y++) {

                    Vector2f arr = new Vector2f(x,y);

                    if (grid.getArmorValue(x, y) <= grid.getMaxArmorInCell()/2 && !firedCells.contains(arr)) {
                        //activated = true; //bad
                        
                        firedCells.add(arr);
                        
                        
                        //To spawn the projectile
                        Vector2f vec = grid.getLocation(x, y);
                        float angle = VectorUtils.getAngle(ship.getLocation(), vec); //from, too
                        //WeaponAPI weapon = engine.createFakeWeapon(ship, "hellbore");
                        //                    ship  weapAPI weapName
                        if(ship.getHullSize() == HullSize.FIGHTER) {
                            engine.spawnProjectile(ship, null, "hellomod_reactivecharge_fighter", vec, angle, ship.getVelocity());
                        } else {
                            engine.spawnProjectile(ship, null, "hellomod_reactivecharge", vec, angle, ship.getVelocity()); //ship and weap can be null
                        }
                    }
                } //for
            } //for
        }
    }
}