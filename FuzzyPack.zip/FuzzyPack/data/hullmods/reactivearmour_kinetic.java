package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ArmorGridAPI;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;

import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.listeners.AdvanceableListener;
import java.util.ArrayList;
import org.lazywizard.lazylib.MathUtils;


import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;


public class reactivearmour_kinetic extends BaseHullMod {
    
    private float EMP_resist = 0.75f;
    
    @Override
    public void applyEffectsBeforeShipCreation(ShipAPI.HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getEmpDamageTakenMult().modifyMult("reKI_id", EMP_resist);
    }

    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        ship.addListener(new listener(ship));
    }

    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        return !ship.getVariant().hasHullMod("fp_reactivearmour_he");
    }


    @Override
    public String getUnapplicableReason(ShipAPI ship) {
        if (ship.getVariant().hasHullMod("fp_reactivearmour_he")) {
            return "Can only install one type of Reactive Armour";
        }
        return null;
    }

    class listener implements AdvanceableListener {

        CombatEngineAPI engine = Global.getCombatEngine();

        ShipAPI ship;
        
        ArrayList<Vector2f> firedCells = new ArrayList<Vector2f>();


        public listener(ShipAPI ship)
        {
            this.ship = ship;
        }

        @Override
        public void advance(float amount)
        {
            if (ship.isHulk()) return;

            ArmorGridAPI grid = ship.getArmorGrid();

            int gridWidth = grid.getGrid().length;
            int gridHeight = grid.getGrid()[0].length;
            

            for (int x = 0; x < gridWidth; x++) {
                for (int y = 0; y < gridHeight; y++) {

                    Vector2f arr = new Vector2f(x,y);

                    if (grid.getArmorValue(x, y) <= grid.getMaxArmorInCell()/2 && !firedCells.contains(arr)) {
                        
                        firedCells.add(arr);
                        ship.getMutableStats().getEmpDamageTakenMult().unmodify("reKI_id");
                        
                        //To spawn the projectile
                        Vector2f vec = grid.getLocation(x, y);
                        float angle = VectorUtils.getAngle(ship.getLocation(), vec); //from, too
                        
                        for (int i = 0; i < 2; i++) {
                            engine.spawnProjectile(ship, null, "fp_reactivekinetic", vec, 
                                    MathUtils.getRandomNumberInRange(angle -5f, angle +5f), ship.getVelocity()); //ship and weap can be null
                        }
                    }
                    
                    if (grid.getArmorValue(x, y) > grid.getMaxArmorInCell()/2 && firedCells.contains(arr)) {
                        firedCells.remove(arr);
                    }
                    
                } //for
            } //for
        }
    }
    
    public String getDescriptionParam(int index, ShipAPI.HullSize hullSize) {
        if (index == 0) return Math.round(50) + "%";
        if (index == 1) return Math.round((1-EMP_resist)*100) + "%";
        return null;
    }
    
}