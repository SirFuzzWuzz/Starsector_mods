package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShieldAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;


public class shield_fuckery extends BaseHullMod {

	//public ShipAPI ship;
	
	//public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		//ship.getShield().setRadius(0);
	//}
    
    
        public void advanceInCombat(ShipAPI ship, float amount) {
            //ShieldAPI shield = ship.getShield();
            
            ship.getShield().setInnerRotationRate((float) Math.sin(10*amount)*1000);
            
            
        }
	
	
        //Built-in only
        @Override
        public boolean isApplicableToShip(ShipAPI ship) {
            return true;
        }

}

