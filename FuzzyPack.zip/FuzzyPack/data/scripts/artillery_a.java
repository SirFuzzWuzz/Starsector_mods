package data.scripts;


import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseCombatLayeredRenderingPlugin;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;

import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.loading.DamagingExplosionSpec;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;

import org.lwjgl.util.vector.Vector2f;
//import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.MathUtils;
//import com.fs.starfarer.api.util.IntervalUtil;
//import com.fs.starfarer.api.util.Misc;

public class artillery_a extends BaseCombatLayeredRenderingPlugin implements OnHitEffectPlugin {
    

    
    private final float minRange = 400;
    private final float projspeed = 400;
    
    
    //private boolean fire = false;
    private float range;
    //private Vector2f hitLoc;
   
    //protected IntervalUtil interval;

    
    
    public artillery_a() {}

    @Override
    public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target,
					  Vector2f point, boolean shieldHit, ApplyDamageResultAPI damageResult, CombatEngineAPI engine) {
        
        ShipAPI ship = projectile.getSource();
        //int range = (int) Math.sqrt(Math.pow(ship.getLocation().getX() - target.getLocation().getX(),2) + Math.pow(ship.getLocation().getY() - target.getLocation().getY(), 2));
        range = (float) MathUtils.getDistance(ship, target);

        if (range > minRange) {
            float t = (range/projspeed);
            interval = new IntervalUtil(t,t+0.1f);
            
            //engine.addFloatingText(point, "time = " + t, 11, Color.white, ship, 1, 2);

            
            artillery_a pg = new artillery_a(point, interval, engine, ship);
            CombatEntityAPI e = engine.addLayeredRenderingPlugin(pg);
            
            
        } else if (ship == engine.getPlayerShip()) {
            engine.addFloatingText(point, "Target is too close!", 11, Color.white, ship, 1, 2);
        }
 
    }
    
    
    protected IntervalUtil interval;
    protected Vector2f hitLoc;
    protected boolean fired;
    protected CombatEngineAPI engine;
    protected ShipAPI ship;
    
    
    public artillery_a(Vector2f hitLoc, IntervalUtil interval, CombatEngineAPI engine, ShipAPI ship) {
        this.interval = interval;
        this.hitLoc = hitLoc;
        this.fired = false;
        this.engine = engine;
        this.ship = ship;
        
    }
    
    
    @Override
    public void advance(float amount) {
        
        if (interval.intervalElapsed()) {
    
            //engine.addFloatingText(hitLoc, " advance", 11, Color.white, null, 1, 2);
            DamagingExplosionSpec exp = new DamagingExplosionSpec(
            0.3f, //dur
            300, //rad
            100, //core
            800, //maxDmg 1000f
            400, //minDmg 500f
            CollisionClass.MISSILE_FF, //collision
            CollisionClass.MISSILE_FF, //fighter collision
            0.1f, //min particle size
            1f, // particle size range
            2f, //particle dur
            10, //particle count
            Color.orange, //particle color
            new Color(200, 170, 160, 200)); //explosion color
            engine.spawnDamagingExplosion(exp, ship, hitLoc);

            fired = true;
    }
    interval.advance(amount);
        
    }
    
    
    
    public void init(CombatEntityAPI entity) {
		super.init(entity);
	}
        
    public boolean isExpired() {
            return fired;
    }
    

}
