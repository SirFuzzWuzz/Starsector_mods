package data.scripts;


import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import java.util.ArrayList;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
//import com.fs.starfarer.api.util.IntervalUtil;
//import com.fs.starfarer.api.util.Misc;

public class dakkabox_onfire implements OnFireEffectPlugin {
    
    private static final  ArrayList<String> weaponList = new ArrayList();
    static {
        //Ballistics
        for (int i = 0; i < 2; i++) {
            weaponList.add("lightmg");
            weaponList.add("lightmortar");
            weaponList.add("vulcan");
            weaponList.add("lightac");
            weaponList.add("lightag");
            weaponList.add("fragbomb");
            weaponList.add("clusterbomb");
            weaponList.add("bomb");
            weaponList.add("lightneedler");
            weaponList.add("lightag");
            weaponList.add("lightag");
            weaponList.add("railgun");
            weaponList.add("shredder");
            weaponList.add("heavymg");
            weaponList.add("heavymortar");
            weaponList.add("railgun");
            weaponList.add("arbalest");
            weaponList.add("dualflak");
            weaponList.add("chaingun");
            weaponList.add("heavymauler");
            weaponList.add("heavyac");
            weaponList.add("hveldriver");
            weaponList.add("heavyneedler");
            weaponList.add("gauss");
            weaponList.add("hephag");
            weaponList.add("mark9");
            weaponList.add("devastator");
            weaponList.add("mjolnir");
            weaponList.add("hellbore");
            weaponList.add("multineedler");
            weaponList.add("canister_flak");

            //Energy
            weaponList.add("ioncannon");
            weaponList.add("irpulse");
            weaponList.add("amblaster");
            weaponList.add("pulselaser");
            weaponList.add("miningblaster");
            weaponList.add("heavyblaster");
            weaponList.add("ionpulser");
            weaponList.add("plasma");
            weaponList.add("autopulse");
            weaponList.add("tpc");
        }
        
        //Missiles
        weaponList.add("reaper");
        weaponList.add("atropos");
        weaponList.add("hammer");
        weaponList.add("swarmer");
        weaponList.add("annihilator");
        weaponList.add("heatseeker");
        weaponList.add("harpoon");
        weaponList.add("breach");
        weaponList.add("sabot");
        weaponList.add("pilum");
        weaponList.add("phasecl");
        weaponList.add("phasecl_bomber");
        weaponList.add("hurricane");
        weaponList.add("squall");
        weaponList.add("locust");
        weaponList.add("terminator_missile");
        
        weaponList.add("flarelauncher1");
        weaponList.add("flarelauncher3");   

        }
    
    public int r; 
    public float angle;
    
    public dakkabox_onfire() {}

	public void onFire(DamagingProjectileAPI projectile, WeaponAPI weapon, CombatEngineAPI engine) {
            engine.removeEntity(projectile);
            for (int i = 0; i<12; i++) {
                //int r = MathUtils.getRandomNumberInRange(0, weaponList.size()-1);
                String weap = (String) weaponList.get(r);
                r = MathUtils.getRandomNumberInRange(0, weaponList.size()-1);
                
                angle = MathUtils.getRandomNumberInRange(0, 40);
                VectorUtils.rotate(projectile.getVelocity(), angle, projectile.getVelocity());
                
                engine.spawnProjectile(weapon.getShip(), weapon, weap, weapon.getFirePoint(0), projectile.getFacing()+MathUtils.getRandomNumberInRange(-15,15), weapon.getShip().getVelocity());
                //engine.spawnProjectile(weapon.getShip(), weapon, weap, projectile.getLocation(), projectile.getFacing(), weapon.getShip().getVelocity());
                projectile.getProjectileSpec().setMaxRange(weapon.getRange());
            }
            
            
	}

}
