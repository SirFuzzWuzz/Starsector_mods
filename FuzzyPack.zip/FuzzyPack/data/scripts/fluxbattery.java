package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;


public class fluxbattery implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin {

	public static float fluxCap = 4000;
        public float fluxStored = 0;
        public float fluxDiss = 100/2; //divide by 60 for per frame diss
        public int maxAmmo;
        
        public static Object KEY_TARGET = new Object();
        
        //public ShipAPI ship;
        //public int frameCounter = 0;
        //public int ammo;
        //public boolean chargeBattery = true;
        
        public fluxbattery() {}
        
        public boolean once = true;
        public int counter = 0;
        
        public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {
            
            //check for pause or weapon gone?
            //if (weapon == null || amount <= 0f || weapon.isDisabled()) {return;}
            if (engine.isPaused()) return;
            if (!weapon.getShip().isAlive()) return;
            if (weapon.isDisabled())return;
            
            if (once) {
                maxAmmo = weapon.getMaxAmmo();
                weapon.setAmmo(0);
                
                once = false;
            }
            
            ShipAPI ship = weapon.getShip();
            
            if (counter == 30 && maxAmmo != 0) {
                if (ship.getFluxTracker().getCurrFlux() > fluxDiss  && fluxStored < fluxCap) {
                    ship.getFluxTracker().decreaseFlux(fluxDiss);
                    fluxStored += fluxDiss;

                } else if (fluxStored >= fluxCap) {
                    weapon.setAmmo(1);
                    Vector2f location = weapon.getLocation();
                    Vector2f offsetLoc = weapon.getFirePoint(0);
                    engine.spawnEmpArcVisual(location, ship, offsetLoc, ship, 1f, new Color(200,50,200,120), Color.blue);
                }
                counter = 0;
            }
            counter ++; 
            
            
            /* for left side number
            //If player ship is the ship, left side visual
            if (ship == Global.getCombatEngine().getPlayerShip()) { 
                    Global.getCombatEngine().maintainStatusForPlayerShip(KEY_TARGET, 
                                    ship.getSystem().getSpecAPI().getIconSpriteName(),
                                    "Flux Battery", 
                                    "" + (int)(fluxStored) + " Flux Stored in battery", true);
            }*/

        } 
        
        /*
        public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target,
					  Vector2f point, boolean shieldHit, ApplyDamageResultAPI damageResult, CombatEngineAPI engine) {
            
        }
        */
        
        public void onFire(DamagingProjectileAPI projectile, WeaponAPI weapon, CombatEngineAPI engine) {
            
            if (fluxStored >= fluxCap) {
                fluxStored = 0;
                maxAmmo -=1;
            }

                
        /*
            ShipAPI hostShip = weapon.getShip();
            int currAmmo = weapon.getAmmo();
            
            if (fluxStored < fluxCap) {
                
                hostShip.getFluxTracker().decreaseFlux(500);
                fluxStored += 400;
                weapon.setAmmo(currAmmo +1);
                //weapon.setRefireDelay(0.2f);
                
            } else {
                engine.spawnProjectile(weapon.getShip(), weapon, "battery_launch", projectile.getLocation(), projectile.getFacing(), weapon.getShip().getVelocity());
                fluxStored = 0;
                //weapon.setRefireDelay(10); 
                
            }
            engine.removeEntity(projectile); 
            */
            
        } 

}
