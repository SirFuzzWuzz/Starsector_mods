package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.listeners.AdvanceableListener;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import data.scripts.util.MagicLensFlare;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lwjgl.util.vector.Vector2f;



public class magnetmine implements OnFireEffectPlugin {
    
    private final float maxDist = 600f;
    private final float acc = 1.5f;
    
    //private IntervalUtil interval = new IntervalUtil(15f,15f);

    @Override
    public void onFire(DamagingProjectileAPI projectile, WeaponAPI weapon, CombatEngineAPI engine) {
        weapon.getShip().addListener(new listener(projectile));
    }

    
    class listener implements AdvanceableListener {
        
        CombatEngineAPI engine = Global.getCombatEngine();
        DamagingProjectileAPI proj;
        
        public listener(DamagingProjectileAPI proj) {
            this.proj = proj;
        }
        
        @Override
        public void advance(float amount) {
            if (proj.isExpired()) {
                return; 
            }
            
            ShipAPI trgt = AIUtils.getNearestEnemy(proj);
            
            if (trgt != null) {
                float dist = MathUtils.getDistance(proj.getLocation(), trgt.getLocation());
                if (dist < maxDist) {
                    Vector2f trgtVec = trgt.getLocation();
                    Vector2f projVec = proj.getLocation();

                    float deltaX = trgtVec.x - projVec.x;
                    float deltaY = trgtVec.y - projVec.y;

                    float accX = (deltaX/dist) * acc;
                    float accY = (deltaY/dist) * acc;

                    proj.getVelocity().set(proj.getVelocity().x + accX, proj.getVelocity().y + accY);
                    
                }
            }
            
            
        } //advance
        
    }

}