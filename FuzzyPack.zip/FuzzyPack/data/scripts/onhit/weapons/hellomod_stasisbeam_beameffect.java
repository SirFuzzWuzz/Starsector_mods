package data.scripts.onhit.weapons;

import com.fs.starfarer.api.combat.BeamAPI;
//import com.fs.starfarer.api.combat.BeamEffectPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
//import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.ArrayList;
import org.lwjgl.util.vector.Vector2f;
//import org.lwjgl.util.vector.Vector2f;

public class hellomod_stasisbeam_beameffect implements EveryFrameWeaponEffectPlugin {

	private IntervalUtil fireInterval = new IntervalUtil(0.25f, 1.75f);
        private ShipAPI targetShip;
        //private BeamAPI beam;
        
        private float slowTick = 1;
        
        private int counter = 0;
        
        //public hellomod_vorebeam_beameffect() {}


    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {
        
        /*
        public class EXAMPLE_SlowBeamEffect implements BeamEffectPlugin {

    private IntervalUtil slowInterval = new IntervalUtil(0.1f, 0.1f);
    private boolean wasZero = true;
    
    public void advance(float amount, CombatEngineAPI engine, BeamAPI beam) {
        CombatEntityAPI target = beam.getDamageTarget();
        
        if (target instanceof ShipAPI) {
            float slowDur = beam.getDamage().getDpsDuration();
            wasZero = beam.getDamage().getDpsDuration() <= 0;
            if (!wasZero) slowDur = 0;
            slowInterval.advance(slowDur);
            
            if (slowInterval.intervalElapsed()) {
                Vector2f vel = target.getVelocity();
                vel.x = vel.x * 0.95f;
                vel.y = vel.y * 0.95f;
                target.getVelocity().set(vel);
            }
        }
    }
}
        */
    }

}
