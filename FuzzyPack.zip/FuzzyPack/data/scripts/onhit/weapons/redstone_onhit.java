package data.scripts.onhit.weapons;


import com.fs.starfarer.api.combat.BaseCombatLayeredRenderingPlugin;
import org.lwjgl.util.vector.Vector2f;

//import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipCommand;
import com.fs.starfarer.api.combat.ShipSystemAPI;

import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import java.awt.Color;
//import com.fs.starfarer.api.util.IntervalUtil;
//import com.fs.starfarer.api.util.Misc;

public class redstone_onhit extends BaseCombatLayeredRenderingPlugin implements OnHitEffectPlugin {

	//public static float CRmod = 0.25f; //0.1 = 10% for frigate, 5% less for each size
        
        public redstone_onhit() {
        }

	public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target,
					  Vector2f point, boolean shieldHit, ApplyDamageResultAPI damageResult, CombatEngineAPI engine) {
		if (!shieldHit && target instanceof ShipAPI) {
                    
                    //float dam = 0;
                    //float thickness = 20;

                    
                    if (activateSystem((ShipAPI) target, engine)) {
                        float dam = projectile.getDamageAmount();
                        float emp = projectile.getEmpAmount()*2;
                        float thickness = 50;
                        
                        
                        engine.spawnEmpArc(projectile.getSource(), point, target, target,
                                                       DamageType.HIGH_EXPLOSIVE, 
                                                       dam,
                                                       emp, // emp 
                                                       100000f, // max range 
                                                       "tachyon_lance_emp_impact",
                                                       thickness, // thickness
//							   new Color(70,100,155,255),
//							   new Color(255,255,255,255)
                                                       new Color(180,60,52,255),
                                                       new Color(255,255,255,255)
//								new Color(235,255,215,70),
//								new Color(255,255,255,255)
                                                       );
                    }
		}
	}

        public static boolean activateSystem(ShipAPI target, CombatEngineAPI engine) {
            boolean ret = false;
            /*if (!target.getSystem().isOn() && target.getSystem().isCoolingDown()) {
            target.getSystem().setCooldownRemaining(-1);
            
            } */
            if (target.getAI() == null || target.getSystem() == null) return true;
            
            if (target.getSystem().getId().contains("le_explode")) { //workaround for IED's
                target.getSystem().forceState(ShipSystemAPI.SystemState.IN, 0);
            }

            if (target.getSystem().isCoolingDown() || target.getSystem().isOutOfAmmo() 
                    || target.getSystem().isActive()|| target.getFluxTracker().isVenting() ) {
                ret = true;
            }
            
            target.giveCommand(ShipCommand.USE_SYSTEM, target.getLocation(), 0);
            
            return ret;
        }
        
        
}
