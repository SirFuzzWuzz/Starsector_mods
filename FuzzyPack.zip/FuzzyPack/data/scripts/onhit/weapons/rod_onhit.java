package data.scripts.onhit.weapons;

import org.lwjgl.util.vector.Vector2f;

//import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
//import com.fs.starfarer.api.util.IntervalUtil;
//import com.fs.starfarer.api.util.Misc;

public class rod_onhit implements OnHitEffectPlugin {

	public static float CRmod = 0.25f; //0.1 = 10% for frigate, 5% less for each size
        
        public rod_onhit() {
        }

	public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target,
					  Vector2f point, boolean shieldHit, ApplyDamageResultAPI damageResult, CombatEngineAPI engine) {
		if (!shieldHit && target instanceof ShipAPI) {
                    
                    dealRadDmg((ShipAPI) target);
                    
		}
	}
        
        public static void dealRadDmg(ShipAPI target) {
            float cr = target.getCurrentCR();
            
            if (target.getHullSize() == ShipAPI.HullSize.FRIGATE) {
                    target.setCurrentCR(cr - CRmod);
            } else if (target.getHullSize() == ShipAPI.HullSize.DESTROYER) {
                    target.setCurrentCR(cr - (CRmod - 0.05f));
            } else if (target.getHullSize() == ShipAPI.HullSize.CRUISER) {
                    target.setCurrentCR(cr - (CRmod - 0.10f));
            } else if (target.getHullSize() == ShipAPI.HullSize.CAPITAL_SHIP) {
                    target.setCurrentCR(cr - (CRmod - 0.15f));
            }
           
            target.getMutableStats().getPeakCRDuration().modifyFlat("radiation", -90f);
        }
}
