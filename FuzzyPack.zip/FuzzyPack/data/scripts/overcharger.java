package data.scripts;


import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import java.util.ArrayList;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import com.fs.starfarer.api.util.IntervalUtil;
//import com.fs.starfarer.api.util.Misc;  OnFireEffectPlugin

public class overcharger implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin {
    
    private final float bonusRefire = 0.01f;
    private final float baseRefire = 0.05f; //starting
    private float currRefire = 0.05f; //changes
    private int count;
    

    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {


        if (weapon.isFiring() == false) {
            
            if (count >= 30) {
                count = 0;
                if (currRefire > baseRefire) {
                    currRefire -=  5*bonusRefire;
                }
                weapon.setRefireDelay(currRefire);

                
            } else {
                
            count += 1;
            }
            
        } else  {
            count = 0;
        } 
        

    }
    
    
    @Override
    public void onFire(DamagingProjectileAPI projectile, WeaponAPI weapon, CombatEngineAPI engine) {

        weapon.setRefireDelay(currRefire);
        if (currRefire <= 1.5f) {
            currRefire += bonusRefire;
        }
        //}
        
    }


}