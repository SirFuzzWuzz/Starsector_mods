package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseCombatLayeredRenderingPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;


import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;

import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;

import org.lwjgl.util.vector.Vector2f;
//I'm the best

public class phasegun extends BaseCombatLayeredRenderingPlugin implements OnHitEffectPlugin {

        
        //public static Object KEY_TARGET = new Object();
        
        //public ShipAPI ship;
        //public int frameCounter = 0;
        //public int ammo;
        //public boolean chargeBattery = true;
        
        public phasegun() {
	}
        
        private final float duration = 8f;

        
        public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target,
					  Vector2f point, boolean shieldHit, ApplyDamageResultAPI damageResult, CombatEngineAPI engine) {
            if (projectile.isFading()) return;
            
            if (!shieldHit && target instanceof ShipAPI) {
                ShipAPI targetShip = (ShipAPI) target;
                if (!targetShip.getChildModulesCopy().isEmpty()) return;
                
                phasegun pg = new phasegun(targetShip, duration);
                CombatEntityAPI e = engine.addLayeredRenderingPlugin(pg);
                //engine.addPlugin((EveryFrameCombatPlugin) pg);
            }
	}
        
        
        protected ShipAPI target;
        protected IntervalUtil interval;
        protected boolean hasTarget = false;
        
        public phasegun(ShipAPI ship, float duration) {
            this.target = ship;
            this.interval = new IntervalUtil(duration,duration + 2f);
            this.hasTarget = true;
            
            target.setPhased(true);
            target.setAlphaMult(0.3f);
            
            target.getMutableStats().getPeakCRDuration().modifyMult("pspace_bad", 0f);
        }
        
        public void advance(float amount) { //, CombatEngineAPI engine, WeaponAPI weapon public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon)
            if (Global.getCombatEngine().isPaused()) return;
            
            if (hasTarget) {
                interval.advance(amount);
                
                //Color color = new Color(1, 1, 1, 50);
                Color color_u = new Color(200, 100, 200, 150);
                //target.setJitter(target, color , 2f, 3, 5f);
                target.setJitterUnder(target, color_u , 2f, 3, 5f);
                
                target.setAngularVelocity(5f);
                
                for (WeaponAPI weap : target.getAllWeapons()) {
                    weap.setRefireDelay(1f);
                }
                
                if (interval.intervalElapsed()) {
                    this.target.setPhased(false);
                    this.hasTarget = false;
                    this.target.setJitterUnder(target, Color.MAGENTA, 1f, 3, 0f);
                    target.setAlphaMult(1f);
                    target.getMutableStats().getPeakCRDuration().unmodify("pspace_bad");
                }
                
            } 
        } 
        
        public void init(CombatEntityAPI entity) {
		super.init(entity);
	}
        
        public boolean isExpired() {
		return !target.isAlive() || 
                        !Global.getCombatEngine().isEntityInPlay(target) || !hasTarget;
	}
        
        

}
