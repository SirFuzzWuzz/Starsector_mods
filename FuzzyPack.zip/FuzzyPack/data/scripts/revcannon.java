package data.scripts;


import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import java.util.ArrayList;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
//import com.fs.starfarer.api.util.IntervalUtil;
//import com.fs.starfarer.api.util.Misc;

public class revcannon implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin {
    
    private float baseRefire;
    private boolean firing = false;
    private float bonusRefire = 0.1f;
    private int counter = 0;
    
    
    private boolean once = true;
    

    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {
        /*
        if (once) {
            baseRefire = weapon.getSpec().getChargeTime();
            once = false;
        }
        
        if (counter >= 10 && !fired) {
            if (weapon.getSpec().getChargeTime() <= 1f) {
                weapon.setRefireDelay(baseRefire+0.1f);
            }
        } else {counter ++;}
        */
        float cooldown = weapon.getCooldownRemaining();
        
        if (weapon.isFiring()) {
            if (cooldown > 0.1f) {
            weapon.setRemainingCooldownTo(cooldown- bonusRefire);
            } else {
                return;
            }
        } else if (cooldown <= 1f) {
            weapon.setRemainingCooldownTo(cooldown + bonusRefire);
        }
        
        

    }
    
    /*
    public void onFire(DamagingProjectileAPI projectile, WeaponAPI weapon, CombatEngineAPI engine) {

       // weapon.setRefireDelay(baseRefire -bonusRefire);
        //bonusRefire += bonusRefire;
        firing = true;
        weapon.getSpec().getChargeTime();
    }*/

}
