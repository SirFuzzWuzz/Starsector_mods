package data.scripts;


import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;

import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipCommand;

import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponSize;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;


public class shieldgen implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin {

        
        
        public shieldgen() {
	}
        
        public boolean once = true;
        public ShipAPI drone;
        
        public Color shieldColor; //= new Color(80,60,200,200);
        
        //for EMP visual
        public IntervalUtil interval = new IntervalUtil(0.15f, 0.25f);
        
        public IntervalUtil intShieldOff = new IntervalUtil(1.5f,1.5f);

        @Override
        public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {

            if (once) {
               
                if (weapon.getSpec().getSize() == WeaponSize.LARGE) {
                    drone = engine.getFleetManager(weapon.getShip().getOwner()).spawnShipOrWing("fp_shielddrone_base", 
                            weapon.getLocation(), weapon.getCurrAngle());
                } else {
                    drone = engine.getFleetManager(weapon.getShip().getOwner()).spawnShipOrWing("fp_shielddroneM_base", 
                            weapon.getLocation(), weapon.getCurrAngle());
                }
                
                drone.setShipAI(null);
                
                //No collision with host ship and make into a module
                drone.setCollisionClass(CollisionClass.FIGHTER);
                drone.setParentStation(weapon.getShip());
                
                //To hide stats better, vast bulk already hides flux info
                drone.getSpriteAPI().setTexHeight(0);
                drone.getSpriteAPI().setTexWidth(0);
                
                drone.getShield().setRadius(weapon.getRange()/3);
                drone.setCollisionRadius(weapon.getRange()/3);          
                
                WeaponType type = weapon.getSlot().getWeaponType();
                if (type != WeaponType.BALLISTIC && type != WeaponType.ENERGY && type != WeaponType.HYBRID) {
                    drone.getMutableStats().getShieldDamageTakenMult().modifyMult("shieldgen_id", 1f - 20f * 0.01f);
                }
                /*
                if (type == WeaponType.BALLISTIC) {
                    drone.getMutableStats().getHighExplosiveShieldDamageTakenMult().modifyMult("shieldgen_id", 0.8f);
                } else if (type == WeaponType.ENERGY) {
                    drone.getMutableStats().getKineticShieldDamageTakenMult().modifyMult("shieldgen_id", 0.8f);
                } else if (type == WeaponType.MISSILE) {
                    drone.getMutableStats().getHighExplosiveShieldDamageTakenMult().modifyMult("shieldgen_id", 0.8f);
                    drone.getMutableStats().getKineticShieldDamageTakenMult().modifyMult("shieldgen_id", 0.8f);
                } else if (type == WeaponType.HYBRID) {
                    drone.getMutableStats().getHighExplosiveShieldDamageTakenMult().modifyMult("shieldgen_id", 0.9f);
                    drone.getMutableStats().getKineticShieldDamageTakenMult().modifyMult("shieldgen_id", 0.9f);
                    drone.getMutableStats().getEnergyShieldDamageTakenMult().modifyMult("shieldgen_id", 0.9f);
                } else if (type == WeaponType.SYNERGY) {
                    drone.getMutableStats().getKineticShieldDamageTakenMult().modifyMult("shieldgen_id", 0.8f);
                    drone.getMutableStats().getEnergyShieldDamageTakenMult().modifyMult("shieldgen_id", 0.8f);
                } else if (type == WeaponType.COMPOSITE) {
                    drone.getMutableStats().getHighExplosiveShieldDamageTakenMult().modifyMult("shieldgen_id", 0.8f);
                    drone.getMutableStats().getEnergyShieldDamageTakenMult().modifyMult("shieldgen_id", 0.8f);
                } else if (type == WeaponType.UNIVERSAL) {
                    drone.getMutableStats().getHighExplosiveShieldDamageTakenMult().modifyMult("shieldgen_id", 0.8f);
                    drone.getMutableStats().getKineticShieldDamageTakenMult().modifyMult("shieldgen_id", 0.8f);
                    drone.getMutableStats().getEnergyShieldDamageTakenMult().modifyMult("shieldgen_id", 0.8f);
                } */
                
                
                //Color
                shieldColor = drone.getShield().getInnerColor();
                
                drone.getShield().setRingColor(shieldColor.brighter());
                drone.getShield().setInnerColor(shieldColor.brighter());
                once = false;
            }

            
            if (weapon.isFiring()) {
                intShieldOff.setElapsed(0);
                if (drone.getShield().isOff()) {
                    drone.giveCommand(ShipCommand.TOGGLE_SHIELD_OR_PHASE_CLOAK, null, 0);
                }
                
            } else if (!weapon.isFiring() && drone.getShield().isOn()) {
                if (intShieldOff.intervalElapsed()) {
                    drone.giveCommand(ShipCommand.TOGGLE_SHIELD_OR_PHASE_CLOAK, null, 0);
                }
                intShieldOff.advance(amount);
            } 
            
            
            if (drone.getFluxTracker().isOverloaded() && !weapon.isDisabled()) {
                weapon.disable();
            }
            
            
            //Move the drone to follow the weapon
            drone.getLocation().set(weapon.getLocation().x, weapon.getLocation().y);
            drone.setFacing(weapon.getCurrAngle());
            
            
            //EMP visual
            if (weapon.isFiring() && interval.intervalElapsed()) {
                float rad = drone.getShield().getRadius();
                
                Vector2f onRad = MathUtils.getPointOnCircumference(weapon.getLocation(), rad-15f, 
                        weapon.getCurrAngle() + MathUtils.getRandomNumberInRange(-30, 30));
                
                engine.spawnEmpArcVisual(weapon.getFirePoint(MathUtils.getRandomNumberInRange(0, 4)), drone, onRad, drone, 10f, 
                        new Color(0,0,10,50), shieldColor);
                
            }
            interval.advance(amount);
            
            
            if (!weapon.getShip().isAlive()) {
                engine.removeEntity(drone);
            }
        }
        
        @Override
        public void onFire(DamagingProjectileAPI projectile, WeaponAPI weapon, CombatEngineAPI engine) {
            engine.removeEntity(projectile);
        }
        

}
