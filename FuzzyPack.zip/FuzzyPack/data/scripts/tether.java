package data.scripts;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.lazywizard.lazylib.MathUtils;
import static org.lazywizard.lazylib.MathUtils.getRandomNumberInRange;
import org.lwjgl.util.vector.Vector2f;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.VectorUtils;

public class tether implements EveryFrameWeaponEffectPlugin, OnHitEffectPlugin {


    public List<ShipAPI> shipList = new ArrayList<ShipAPI>();
    public float distSnap; //distance snapshot

    public float minDist = 600f;
    
    private IntervalUtil intervalVisual = new IntervalUtil(0.1f,0.3f);
    
    private IntervalUtil interval = new IntervalUtil(15f,15f);

    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {
        ShipAPI ship = weapon.getShip();
        String key = weapon.getSlot().getId() + "_tethered_ships";
        
        if(ship.getCustomData().containsKey(key)){
            shipList = (List<ShipAPI>) ship.getCustomData().get(key);
        } else return;

        for (ShipAPI targetShip : shipList){
            
            Vector2f shipVec = ship.getLocation();
            Vector2f targetVec = targetShip.getLocation();

            //distCurr = (float) Math.sqrt(Math.pow((shipVec.x - targetVec.x),2) + Math.pow((shipVec.y - targetVec.y),2));
            float distCurr = MathUtils.getDistance(shipVec, targetVec);
            
            if (distCurr > minDist) { //outside of max tether distance

                Vector2f vec = VectorUtils.getDirectionalVector(shipVec, targetVec); //From ship towards target

                float shipMassFrac = ship.getMass() / (ship.getMass() + targetShip.getMass());
                //float massDiff = Math.abs(ship.getMass() - targetShip.getMass());

                float distFrac = (distCurr - minDist) / (weapon.getRange());
                
                

                CombatUtils.applyForce(ship, vec, shipMassFrac*distFrac*100);
                CombatUtils.applyForce(targetShip, VectorUtils.rotate(vec, 180), (1f -shipMassFrac)*distFrac*100);

            }
            
            
            
            
            //Visuals
            intervalVisual.advance(amount);
            if (intervalVisual.intervalElapsed()) {
                
                Color clr = new Color(MathUtils.getRandomNumberInRange(1, 255),
                        MathUtils.getRandomNumberInRange(1, 255), 
                        MathUtils.getRandomNumberInRange(1, 255), 
                        200); //alpha

                int gridWidth = targetShip.getArmorGrid().getGrid().length;
                int gridHeight = targetShip.getArmorGrid().getGrid()[0].length;
                //targetShip.getArmorGrid().getLocation(MathUtils.getRandomNumberInRange(0, gridWidth-1), MathUtils.getRandomNumberInRange(0, gridHeight)-1);
                engine.spawnEmpArcVisual(weapon.getLocation(), weapon.getShip(), 
                        targetShip.getArmorGrid().getLocation(MathUtils.getRandomNumberInRange(0, gridWidth-1), MathUtils.getRandomNumberInRange(0, gridHeight)-1), 
                        targetShip, 6f, clr, new Color(0,0,0,10));
            }

        }
        
        interval.advance(amount);
        if (interval.intervalElapsed()) {
            ship.getCustomData().remove(key);
        }

    }


    @Override
    public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target,
                      Vector2f point, boolean shieldHit, ApplyDamageResultAPI damageResult, CombatEngineAPI engine) {

        if (!shieldHit && target instanceof ShipAPI) {
            
            String key = projectile.getWeapon().getSlot().getId() + "_tethered_ships";
            if (projectile.getSource().getCustomData().containsKey(key)){
                //List<ShipAPI> list = (List<ShipAPI>) projectile.getSource().getCustomData().get(key);
                //list.add((ShipAPI) target);

            } else {
                projectile.getSource().setCustomData(key, Arrays.asList((ShipAPI) target));
                
            }
            
        }


    }


}