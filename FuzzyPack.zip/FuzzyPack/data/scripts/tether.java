package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import data.scripts.util.MagicRender;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

import org.lazywizard.lazylib.MathUtils;

import org.lwjgl.util.vector.Vector2f;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.VectorUtils;

public class tether implements EveryFrameWeaponEffectPlugin, OnHitEffectPlugin {


    public List<ShipAPI> shipList = new ArrayList<ShipAPI>();
    public float distSnap; //distance snapshot

    public float minDist = 600f;
    private int noLinks = 20;
    
    private List<Vector2f> links;

    
    
    private IntervalUtil intervalVisual = new IntervalUtil(0.1f,0.3f);
    private IntervalUtil interval = new IntervalUtil(15f,15f);

    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {
        ShipAPI ship = weapon.getShip();
        String key = weapon.getSlot().getId() + "_tethered_ships";
        
        if(ship.getCustomData().containsKey(key)){
            shipList = (List<ShipAPI>) ship.getCustomData().get(key);
        } else return;

        for (ShipAPI targetShip : shipList){
            
            


        }
            

            
        //Visuals
        for (Vector2f loc : links) {
            MagicRender.battlespace(
            Global.getSettings().getSprite("projectiles", "chainsegment"), //"artillery_shell"
            loc,
            new Vector2f(),
            new Vector2f(50,50),
            new Vector2f(0,0),
            loc.length(),
            0f,
            new Color(255,255,255,240),
            false,
            0.01f,
            0.02f,
            0.01f);
        }
            

        interval.advance(amount);
        if (interval.intervalElapsed()) {
            ship.getCustomData().remove(key);
        }
    }

    


    @Override
    public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target,
                      Vector2f point, boolean shieldHit, ApplyDamageResultAPI damageResult, CombatEngineAPI engine) {

        if (!shieldHit && target instanceof ShipAPI) {
            
            String key = projectile.getWeapon().getSlot().getId() + "_tethered_ships";
            if (projectile.getSource().getCustomData().containsKey(key)){
                //List<ShipAPI> list = (List<ShipAPI>) projectile.getSource().getCustomData().get(key);
                //list.add((ShipAPI) target);
            } else {
                projectile.getSource().setCustomData(key, Arrays.asList((ShipAPI) target));
                
                Vector2f current = projectile.getSource().getLocation();
                Vector2f direction = VectorUtils.getDirectionalVector(projectile.getSource().getLocation(), 
                                                                        target.getLocation());
                float spacing = MathUtils.getDistance(projectile.getSource(), target) / noLinks;
                
                for (int i = 0; i < noLinks; i++) {
                    links.add(current);
                    current = MathUtils.getPoint(current, spacing, VectorUtils.getFacing(direction));
                    
                }
            }
        }
    } //onHit
    



}