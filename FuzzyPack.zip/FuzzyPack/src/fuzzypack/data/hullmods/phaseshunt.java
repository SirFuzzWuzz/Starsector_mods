package fuzzypack.data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShieldAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;


//ty arthr for the idea

public class phaseshunt extends BaseHullMod {
        
        //private ShipAPI ship;
        //private final float upkeep = ship.getPhaseCloak().getFluxPerSecond();
        //private IntervalUtil timer;

        
        @Override
        public boolean shipHasOtherModInCategory(ShipAPI ship, String currMod, String category) {
            return super.shipHasOtherModInCategory(ship, currMod, category); //To change body of generated methods, choose Tools | Templates.
        }
        
        public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
            float diss = stats.getFluxDissipation().base;
            float mult = stats.getShieldUpkeepMult().base;
            stats.getFluxDissipation().modifyFlat(id, diss*mult);
            
        }
        
        @Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		ship.setShield(ShieldAPI.ShieldType.FRONT, 0f, 1f, 1f);
	}
        
        
        @Override
        public boolean isApplicableToShip(ShipAPI ship) {
            return ship.getHullSpec().isPhase(); // not null = has phase = true = big brain
        }
        
        
        @Override
	public String getUnapplicableReason(ShipAPI ship) {
                /*if (ship.getVariant().hasHullMod(HullMods.PHASE_ANCHOR)) {
			return "Incompatible with Phase Anchor";
		}*/
		if (!ship.getHullSpec().isPhase()) {
			return "Can only be installed on phase ships";
		}
		return super.getUnapplicableReason(ship);
	}
	
        /*
	public String getDescriptionParam(int index, HullSize hullSize) {

		return null;
	} */
	

}
