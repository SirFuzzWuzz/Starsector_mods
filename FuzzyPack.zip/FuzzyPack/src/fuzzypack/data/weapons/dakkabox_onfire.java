package fuzzypack.data.weapons;


import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;

import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.loading.WeaponSpecAPI;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;

public class dakkabox_onfire implements OnFireEffectPlugin {
    public dakkabox_onfire() {}
    
    private static final List<WeaponSpecAPI> weaponList = Global.getSettings().getAllWeaponSpecs();

	public void onFire(DamagingProjectileAPI projectile, WeaponAPI weapon, CombatEngineAPI engine) {
            engine.removeEntity(projectile);
            for (int i = 0; i<12; i++) {
                    int r = MathUtils.getRandomNumberInRange(0, weaponList.size() - 1);
                    WeaponSpecAPI weap = weaponList.get(r);

                try {
                    if (weap.isBeam() || (weap.getType() == WeaponAPI.WeaponType.MISSILE && Math.random() < 0.8f) || weap.getWeaponId().contains("dummy")) {
                        i -= 1;
                        continue;
                    }
                    DamagingProjectileAPI proj = (DamagingProjectileAPI) engine.spawnProjectile(weapon.getShip(), weapon, weap.getWeaponId(), weapon.getFirePoint(0), projectile.getWeapon().getCurrAngle() + MathUtils.getRandomNumberInRange(-15, 15), weapon.getShip().getVelocity());
                } catch (Exception e) {
                    System.out.println("Dakka Dispenser crashed firing: " + weap.getWeaponId());
                }
            }
            
            
	}

}
