package fuzzypack.data.weapons;


import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import java.util.ArrayList;
import java.util.List;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import org.lazywizard.lazylib.MathUtils;

public class dakkabox_onfire implements OnFireEffectPlugin {
    private static final String[] BLACKLISTED_WEAPONS = {
        "MSS_thumper", "MSS_thumper_sub",
        "nskr_emgl", "nskr_emgl_sub", 
        "fp_artillery", "fp_artillery_spawn",
        "prv_spatterflamer", "prv_spattergun", "prv_spattergun_1", "prv_spattergun_2",
        "prv_spattergun_fighter", "prv_spattergun_fighter_1", "prv_spattergun_fighter_2",
        "uaf_swaras_m_mlrs", "uaf_swaras_l_mlrs",
        "vayra_shockweb_canister", "vayra_canister","catun",
        "KoT", "dummy", "copy", "armaa", "goat"
    };

    protected static final List<String> blacklist = new ArrayList<>();
    private static List<WeaponSpecAPI> validWeapons = null; // Cache the valid weapons
    
    static {
        blacklist.addAll(Arrays.asList(BLACKLISTED_WEAPONS));
        initializeValidWeapons(); // Pre-filter weapons on class load
    }
    private static void initializeValidWeapons() {
    validWeapons = new ArrayList<>();
    List<WeaponSpecAPI> allWeapons = Global.getSettings().getAllWeaponSpecs();
    
    for (WeaponSpecAPI weap : allWeapons) {
        if (!shouldSkipWeapon(weap)) {
            validWeapons.add(weap);
        }
    }
    }
    private boolean shouldSkipWeapon(WeaponSpecAPI weap) {
        // Skip beams
        if (weap.isBeam()) return true;

        // Skip weapons with onHit effects (these often cause issues when spawned randomly)
        if (weap.getOnHitEffect() != null && !weap.getOnHitEffect().isEmpty()) return true;
        
        // Skip weapons with onFire effects (these might also cause issues)
        if (weap.getOnFireEffect() != null && !weap.getOnFireEffect().isEmpty()) return true;
    
        // Check if weapon ID contains any blacklisted strings
        String weaponId = weap.getWeaponId().toLowerCase();
        for (String blacklistedTerm : blacklist) {
            if (weaponId.contains(blacklistedTerm.toLowerCase()) || blacklistedTerm.toLowerCase().contains(weaponId)) {
                return true;
            }
        }
        
        return false;
    }
    public void onFire(DamagingProjectileAPI projectile, WeaponAPI weapon, CombatEngineAPI engine) {
        engine.removeEntity(projectile);
        
        // Use the pre-filtered weapon list
        if (validWeapons == null || validWeapons.isEmpty()) return;
        
        for (int i = 0; i < 12; i++) {
            // Apply missile filtering at runtime (since it uses random)
            WeaponSpecAPI weap;
            int attempts = 0;
            do {
                int r = MathUtils.getRandomNumberInRange(0, validWeapons.size() - 1);
                weap = validWeapons.get(r);
                attempts++;
            } while (weap.getType() == WeaponAPI.WeaponType.MISSILE && Math.random() < 0.75f && attempts < 10);
            
            try {
                engine.spawnProjectile(weapon.getShip(), weapon, weap.getWeaponId(), 
                    weapon.getFirePoint(0), 
                    projectile.getWeapon().getCurrAngle() + MathUtils.getRandomNumberInRange(-15, 15), 
                    weapon.getShip().getVelocity());
            } catch (Exception e) {
                i--; // Don't count failed attempts
            }
        }
    }

}
