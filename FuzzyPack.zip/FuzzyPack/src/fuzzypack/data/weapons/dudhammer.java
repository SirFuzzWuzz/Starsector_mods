package fuzzypack.data.weapons;


import com.fs.starfarer.api.combat.CombatEngineAPI;

import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;

import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;

import com.fs.starfarer.api.combat.WeaponAPI;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.RepLevel;


public class dudhammer implements OnFireEffectPlugin {


        
        //public static Object KEY_TARGET = new Object();
        
        //public ShipAPI ship;
        //public int frameCounter = 0;
        //public int ammo;
        //public boolean chargeBattery = true;
        
        public dudhammer() {}
        
        
        /*        public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {
        
        } */

        @Override
        public void onFire(DamagingProjectileAPI projectile, WeaponAPI weapon, CombatEngineAPI engine) {


                int rng = (int) Math.round(Math.random());
                if (Global.getSector().getFaction("luddic_path").getRelToPlayer().getLevel() == RepLevel.COOPERATIVE){rng = 0;}
                
                if (Math.round(rng) == 0) {
                    projectile.getDamage().setType(DamageType.FRAGMENTATION);
                    
                    MissileAPI missile = (MissileAPI) projectile;
                    //missile.getSpec().setGlowColor(Color.yellow);
                    missile.flameOut();
                    
                     //missile.getSpec().setExplosionColor(Color.yellow);
                }
                    
            
            }

                
        /*
            ShipAPI hostShip = weapon.getShip();
            int currAmmo = weapon.getAmmo();
            
            if (fluxStored < fluxCap) {
                
                hostShip.getFluxTracker().decreaseFlux(500);
                fluxStored += 400;
                weapon.setAmmo(currAmmo +1);
                //weapon.setRefireDelay(0.2f);
                
            } else {
                engine.spawnProjectile(weapon.getShip(), weapon, "battery_launch", projectile.getLocation(), projectile.getFacing(), weapon.getShip().getVelocity());
                fluxStored = 0;
                //weapon.setRefireDelay(10); 
                
            }
            engine.removeEntity(projectile); 
            */
            

}
