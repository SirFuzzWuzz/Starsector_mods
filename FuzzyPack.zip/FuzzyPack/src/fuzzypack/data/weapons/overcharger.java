package fuzzypack.data.weapons;


import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
/*import java.util.ArrayList;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
*/
//import com.fs.starfarer.api.util.Misc;  OnFireEffectPlugin
import com.fs.starfarer.api.util.IntervalUtil;

public class overcharger implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin {
    
    private final float bonusRefire = 0.005f;//added per shot
    private final float regenRefire = 0.01f;//regen rate
    
    private final float baseRefire = 0.05f; //base value as reference
    
    private float currRefire = 0.05f; //current refire rate
    //private int count;
    private final IntervalUtil interval = new IntervalUtil(0.5f,0.5f);
    

    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {


        if (weapon.isFiring() == false) {
            
            if (interval.intervalElapsed()) {
                //count = 0;
                if (currRefire > baseRefire) {
                    currRefire -=  regenRefire;
                }
                weapon.setRefireDelay(currRefire);
                
            } 
            interval.advance(amount);

        } else {
            interval.setElapsed(0);
        }
        

    }
    
    
    @Override
    public void onFire(DamagingProjectileAPI projectile, WeaponAPI weapon, CombatEngineAPI engine) {

        if (currRefire <= 0.25f) {
            currRefire += bonusRefire;
        }
        weapon.setRefireDelay(currRefire);
        
    }


}