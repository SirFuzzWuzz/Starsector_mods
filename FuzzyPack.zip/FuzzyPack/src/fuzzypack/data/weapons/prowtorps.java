package fuzzypack.data.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;

public class prowtorps implements EveryFrameWeaponEffectPlugin {
    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {
        if (engine.isPaused() || !weapon.getShip().isAlive()) return;

        if (weapon.isDisabled()) {
            weapon.repair();
        }

        if (!weapon.getShip().getChildModulesCopy().get(0).isAlive()) {
            weapon.setAmmo(0);
        }


    }
}
