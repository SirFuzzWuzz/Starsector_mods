package fuzzypack.data.weapons;


import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;

//import com.fs.starfarer.api.util.Misc;  OnFireEffectPlugin

public class revcannon implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin {
    
    private final float bonusRefire = 0.1f;
    private final float baseRefire = 1.2f; //slowest
    private float currRefire = 1.2f; //changes 
    private int count;
    
    //private boolean once = true;
    

    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {


        if (weapon.isFiring() == false) {
            
            if (count >= 60) {
                count = 0;
                if (currRefire < baseRefire) {
                    currRefire +=  bonusRefire;
                }
                weapon.setRefireDelay(currRefire);

                
            } else {
                
            count += 1;
            }
            
        } else  {
            count = 0;
        } 
        

    }
    
    
    @Override
    public void onFire(DamagingProjectileAPI projectile, WeaponAPI weapon, CombatEngineAPI engine) {

       // weapon.setRefireDelay(baseRefire -bonusRefire);
        //bonusRefire += bonusRefire;
        //float curr = weapon.getCooldown();
        //if (currRefire <= 0.2) {
        weapon.setRefireDelay(currRefire);
        if (currRefire >= 0.3f) {
            currRefire -= bonusRefire;
        }
        //}
        
    }


}