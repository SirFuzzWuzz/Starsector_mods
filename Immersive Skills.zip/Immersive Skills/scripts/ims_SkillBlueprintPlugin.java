package scripts;

import java.awt.Color;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.SkillSpecAPI;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.CargoTransferHandlerAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.campaign.impl.items.BaseSpecialItemPlugin;
import com.fs.starfarer.api.campaign.impl.items.BlueprintProviderItem;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.util.ArrayList;


public class ims_SkillBlueprintPlugin extends BaseSpecialItemPlugin { //implements BlueprintProviderItem
    
        
        protected SkillSpecAPI skill;
	//protected FighterWingSpecAPI wing;
	
        
        @Override
        public void init(CargoStackAPI stack) {
            super.init(stack);
            skill = Global.getSettings().getSkillSpec(stack.getSpecialDataIfSpecial().getData());
            //skill = Global.getSettings().getSkillSpec("damage_control");
        }
	
	
        public List<String> getProvidedSkill() { 
            List<String> result = new ArrayList<String>();
            result.add(skill.getId());
            return result;
        }
	
	@Override
	public String getDesignType() {
		if (skill != null) {
			//return fighter.getHullSpec().getManufacturer();
                        return skill.getGoverningAptitudeId();
		}
		return null;
	}
        
        public void render(float x, float y, float w, float h, float alphaMult,
                                    float glowMult, SpecialItemRendererAPI renderer) {
		float cx = x + w/2f;
		float cy = y + h/2f;
		
                float blX = cx - 30f;
		float blY = cy - 15f;
		float tlX = cx - 20f;
		float tlY = cy + 26f;
		float trX = cx + 23f;
		float trY = cy + 26f;
		float brX = cx + 15f;
		float brY = cy - 18f;
		
		SpriteAPI sprite = Global.getSettings().getSprite(skill.getSpriteName());
		
		String industryId = stack.getSpecialDataIfSpecial().getData();
		boolean known = Global.getSector().getPlayerFaction().knowsIndustry(industryId);
		
		float mult = 1.5f;
		
		sprite.setAlphaMult(alphaMult * mult);
		sprite.setNormalBlend();
		sprite.renderWithCorners(blX, blY, tlX, tlY, trX, trY, brX, brY);
		
		if (glowMult > 0) {
			sprite.setAlphaMult(alphaMult * glowMult * mult); //*0.5f
			sprite.setAdditiveBlend();
			sprite.renderWithCorners(blX, blY, tlX, tlY, trX, trY, brX, brY);
		}
		
		if (known) {
			renderer.renderBGWithCorners(Color.black, blX, blY, tlX, tlY, trX, trY, brX, brY, 
					 alphaMult * 0.5f, 0f, false);
		}
		
		renderer.renderScanlinesWithCorners(blX, blY, tlX, tlY, trX, trY, brX, brY, alphaMult, false);
	}
            
	@Override
	public int getPrice(MarketAPI market, SubmarketAPI submarket) {
            /*if (skill != null) {
            return super.getPrice(market, submarket);
            }*/
            return super.getPrice(market, submarket)*skill.getTier();
	}
	
	@Override
	public String getName() {
		if (skill != null) {
			return skill.getName() + " Blueprint";
		}
		return super.getName();
	}

	@Override
	public void createTooltip(TooltipMakerAPI tooltip, boolean expanded, CargoTransferHandlerAPI transferHandler, Object stackSource) {
		super.createTooltip(tooltip, expanded, transferHandler, stackSource);
		
		float pad = 3f;
		float opad = 10f;
		float small = 5f;
		Color h = Misc.getHighlightColor();
		Color g = Misc.getGrayColor();
		Color b = Misc.getButtonTextColor();
		b = Misc.getPositiveHighlightColor();
		
		boolean known = Global.getSector().getPlayerStats().hasSkill(skill.getId());
                
		//Description desc = Global.getSettings().getDescription(skill.getId(), Type.CUSTOM); //type?
		//tooltip.addPara(desc.getText1FirstPara(), opad);
                tooltip.addPara(skill.getDescription(), opad);

		
		addCostLabel(tooltip, opad, transferHandler, stackSource);
		
		if (known) {
			tooltip.addPara("Already known", g, opad);
		} else {
			tooltip.addPara("Right-click to learn", b, opad);
		}
	}

	@Override
	public boolean hasRightClickAction() {
		return true;
	}

	@Override
	public boolean shouldRemoveOnRightClickAction() {
		return !Global.getSector().getPlayerStats().hasSkill(skill.getId());
                        
	}
        
	@Override
	public void performRightClickAction() {
		//String skillId = stack.getSpecialDataIfSpecial().getData();
                float currLvl = Global.getSector().getPlayerStats().getSkillLevel(skill.getId());
                
		if (Global.getSector().getPlayerStats().hasSkill(skill.getId()) && currLvl < 2f) {
                        
			Global.getSector().getCampaignUI().getMessageDisplay().addMessage(
					"" + skill.getName() + ": blueprint already known");
		} else {
                        Global.getSector().getPlayerStats().setSkillLevel(skill.getId(), currLvl +1);
                        
			Global.getSoundPlayer().playUISound("ui_acquired_blueprint", 1, 1);
			//Global.getSector().getPlayerFaction().addKnownFighter(skillId, true);
			Global.getSector().getCampaignUI().getMessageDisplay().addMessage(
					"Acquired blueprint: " + skill.getName() + "");//, 
		}
	}

	@Override
	public String resolveDropParamsToSpecificItemData(String params, Random random) throws JSONException {
		if (params == null || params.isEmpty()) return null;
		
		if (!params.startsWith("{")) {
			return params;
		}
		JSONObject json = new JSONObject(params);
		
		int tier = json.optInt("tier", -1);
		Set<String> tags = new HashSet<String>();
		if (json.has("tags")) {
			JSONArray tagsArray = json.getJSONArray("tags");
			for (int i = 0; i < tagsArray.length(); i++) {
				tags.add(tagsArray.getString(i));
			}
		}
		
		return pickSkill(tier, tags, random);
	}

	
	protected String pickSkill(int tier, Set<String> tags, Random random) {
            
                List<String> skillIdList = (List<String>) Global.getSettings().getSkillIds();
                /*List<SkillSpecAPI> specs = null;
                
                for (String id : skillIdList) {
                specs.add(Global.getSettings().getSkillSpec(id));
                }*/
		Iterator<String> iter = skillIdList.iterator();
                
                if (tier >= 0) {
                    while (iter.hasNext()) {
                        String currId = (String) iter.next();
                        
                        SkillSpecAPI curr = (SkillSpecAPI) Global.getSettings().getSkillSpec(currId);
                        
                        if (curr.getTier() != tier) iter.remove();
                    }
                }
		
                if (!tags.isEmpty()) {
                    iter = skillIdList.iterator();
                    while (iter.hasNext()) {
                        String currId = (String) iter.next();

                        SkillSpecAPI curr = (SkillSpecAPI) Global.getSettings().getSkillSpec(currId);
                        
                        for (String tag : tags) {
                            boolean not = tag.startsWith("!");
                            tag = not ? tag.substring(1) : tag;
                            boolean has = curr.hasTag(tag);
                            if (not == has) {
                                iter.remove();
                                break;
                            }
                        }
                    }
                }
		
		WeightedRandomPicker<SkillSpecAPI> picker = new WeightedRandomPicker<SkillSpecAPI>(random);
		for (String currId : skillIdList) {
                    SkillSpecAPI curr = (SkillSpecAPI) Global.getSettings().getSkillSpec(currId);
                    
                    picker.add(curr, 1f * curr.getTier());
		}
		SkillSpecAPI pick = (SkillSpecAPI) picker.pick();
		if (pick == null) {
			return null;
		} else {
			return pick.getId(); 
		}
	}

	
}





