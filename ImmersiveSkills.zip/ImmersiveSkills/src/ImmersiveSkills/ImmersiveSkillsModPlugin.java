package ImmersiveSkills;

import ImmersiveSkills.campaign.AddLootListener;
import ImmersiveSkills.campaign.SpawnDerelictFleetMembersOnDeathListener;
import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;


public class ImmersiveSkillsModPlugin extends BaseModPlugin {
    @Override
    public void onApplicationLoad() throws Exception {
        super.onApplicationLoad();

        // Test that the .jar is loaded and working, using the most obnoxious way possible.
        //throw new RuntimeException("Template mod loaded! Remove this crash in TemplateModPlugin.");
    }

    @Override
    public void onNewGame() {
        super.onNewGame();

        // The code below requires that Nexerelin is added as a library (not a dependency, it's only needed to compile the mod).
//        boolean isNexerelinEnabled = Global.getSettings().getModManager().isModEnabled("nexerelin");

//        if (!isNexerelinEnabled || SectorManager.getManager().isCorvusMode()) {
//                    new MySectorGen().generate(Global.getSector());
            // Add code that creates a new star system (will only run if Nexerelin's Random (corvus) mode is disabled).
//        }
    }

    @Override
    public void onGameLoad(boolean newGame) {
        SpawnDerelictFleetMembersOnDeathListener.attachToPlayerFleetIfNotPresent();

        //Global.getSector().addListener(new AddLootListener());
        Global.getSector().getListenerManager().addListener(new AddLootListener(true), true);

        //System.out.println("Initialized Listeners");
    }


}
