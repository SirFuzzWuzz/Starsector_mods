package ImmersiveSkills.campaign;

import ImmersiveSkills.skills.ims_SkillBlueprintPlugin;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.listeners.ShowLootListener;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.characters.SkillSpecAPI;
import com.fs.starfarer.api.util.Misc;

import org.lazywizard.lazylib.MathUtils;
import java.util.ArrayList;
import java.util.List;

public class AddLootListener extends BaseCampaignEventListener implements ShowLootListener {
    //To spawn skill bp loot

    public AddLootListener(boolean permaRegister) {
        super(permaRegister);
    }

    @Override
    public void reportEncounterLootGenerated(FleetEncounterContextPlugin plugin, CargoAPI loot) {
        System.out.println("Fleet bp loot script, should only run once");

        CampaignFleetAPI loser = plugin.getLoser();
        if (loser == null) return;

        for (FleetEncounterContextPlugin.FleetMemberData member : plugin.getLoserData().getOwnCasualties()) {
            if (member.getMember().getHullId().contains("remnant_station")) {
                loot.addSpecial(new SpecialItemData("ims_skill_bp", "automated_ships"), 1);
                break;
            }
            if (member.getMember().getHullId().contains("tesseract")) {
                loot.addSpecial(new SpecialItemData("ims_skill_bp", "hypercognition"), 1);
                break;
            }

        }


        PersonAPI commander = loser.getFleetData().getCommander();
        if (commander == null) return;

        List<MutableCharacterStatsAPI.SkillLevelAPI> skillList = commander.getStats().getSkillsCopy();

        List<SkillSpecAPI> relevantSkills = new ArrayList<>();
        for (MutableCharacterStatsAPI.SkillLevelAPI skillLvl : skillList) {
            SkillSpecAPI skill = skillLvl.getSkill();
            if (skill.getTier() == 6 || !skill.getTags().contains("bp")) continue;
            if (skill.getTags().contains("combat") || skill.getTags().contains("leader")) {

                relevantSkills.add(skill);
            }
        }
        if (relevantSkills.isEmpty()) return;

        float dropChance = ((float) commander.getStats().getLevel()) / 25f; //Divide by more for lower chance
        //float dropChance = 2;
        if (Math.random() > dropChance) return;
        SpecialItemData bp = new SpecialItemData("ims_skill_bp",
                relevantSkills.get(MathUtils.getRandomNumberInRange(0, relevantSkills.size()-1)).getId());
        if (bp.getId().isEmpty()) return; //maybe unnecessary

        loot.addSpecial(bp, 1);

    }

    @Override
    public void reportAboutToShowLootToPlayer(CargoAPI loot, InteractionDialogAPI dialog) {
        //System.out.println("interaction custom entity type: " + dialog.getInteractionTarget().getCustomEntityType());
        if (dialog.getInteractionTarget().getCustomEntityType() == null) return;
        //if (dialog.getInteractionTarget() == null) return;


        ims_SkillBlueprintPlugin skill_bp = new ims_SkillBlueprintPlugin();
        //if (Math.random() > 0.8) return;
        int tier = MathUtils.getRandomNumberInRange(1, 5);

        int noSkills = (int) Math.round(1+Math.random());
        if(tier > 3) noSkills = 1; //pRoGrAmMiNg

        for (int i = 0; i < noSkills; i++) {
            switch (dialog.getInteractionTarget().getCustomEntityType()) {
                case "station_mining_remnant":
                    try {
                        String skillId = skill_bp.resolveDropParamsToSpecificItemData("{tags:[bp, ind], tier:" +
                                tier + "}", Misc.random);
                        loot.addSpecial(new SpecialItemData("ims_skill_bp", skillId), 1);
                    } catch (RuntimeException e) {
                        throw new RuntimeException(e);
                    }
                    break;

                case "station_research_remnant":
                    try {
                        String skillId = skill_bp.resolveDropParamsToSpecificItemData("{tags:[bp, tech], tier:" +
                                tier + "}", Misc.random);
                        loot.addSpecial(new SpecialItemData("ims_skill_bp", skillId), 1);
                    } catch (RuntimeException e) {
                        throw new RuntimeException(e);
                    }
                    break;

                case "orbital_habitat_remnant":
                    try {
                        String skillId = skill_bp.resolveDropParamsToSpecificItemData("{tags:[bp], tier:" +
                                tier + "}", Misc.random);
                        loot.addSpecial(new SpecialItemData("ims_skill_bp", skillId), 1);
                    } catch (RuntimeException e) {
                        throw new RuntimeException(e);
                    }
                    break;

                default:
                    break;
            }
        } //for
    }


}
