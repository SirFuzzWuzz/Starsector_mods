package ImmersiveSkills.campaign;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.ui.SectorMapAPI;

public class DerelictFleetIntel extends BaseIntelPlugin {

    protected SectorEntityToken location;
    protected boolean important;

    public DerelictFleetIntel(SectorEntityToken location) {
        this.location = location;
        this.important = true;
    }

    @Override
    public boolean isDone() {
        return (Global.getSector().getPlayerFleet().getLocation() == location.getLocation());
    }

    @Override
    public SectorEntityToken getMapLocation(SectorMapAPI map) {
        return location;
    }

    @Override
    public boolean isImportant() {
        return important;
    }



}
